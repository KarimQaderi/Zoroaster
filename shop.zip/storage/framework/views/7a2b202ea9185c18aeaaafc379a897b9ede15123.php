<div class="<?php echo e($field->class); ?>">
    <?php echo $data; ?>

</div>