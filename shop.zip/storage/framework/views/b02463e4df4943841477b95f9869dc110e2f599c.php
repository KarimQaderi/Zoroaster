<?php echo e(Zoroaster::getOptionsSelect($field,$data->{$field->name},'label')); ?>

