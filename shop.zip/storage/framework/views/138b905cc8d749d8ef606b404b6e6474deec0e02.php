<?php if(empty($field->routeShow)): ?>
    <?php echo e($data->{$field->displayTitleField}); ?>

<?php else: ?>
    <?php if(empty($data)): ?>
        چیزی پیدا نشد
    <?php else: ?>
        <a href="<?php echo e(route($field->routeShow,['resource'=>\Zoroaster::getNameResourceByModelName($field->model),'resourceId'=>$data->{$field->foreign_key}])); ?>"><?php echo e($data->{$field->displayTitleField}); ?></a>
    <?php endif; ?>
<?php endif; ?>