<label>
    <button class="uk-button uk-button-primary">ذخیره</button>
</label>