<?php $__currentLoopData = $ActionButtonRow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $btn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a
            <?php $__currentLoopData = isset($btn['attr'])? $btn['attr'] : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_key=>$_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php echo e($_key); ?>="<?php echo e($_value); ?>"
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            href="<?php echo e(route($btn['route'],$value->{$key})); ?>"><?php echo e($btn['label']); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
