<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
    <span class="uk-text-warning uk-text-small-2"><?php echo e(BuilderFields::getMeta($field,'helpText')); ?></span>
    <input class="uk-input" name="<?php echo e($data->name); ?>" type="text" value="<?php echo e($data->value); ?>">
</label>