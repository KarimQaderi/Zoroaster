<label>
    <span class="label"><?php echo e($field->label); ?></span>
    <div class="body"><span class="uk-border-pill <?php if($data->{$field->name}===1): ?> boolen-green <?php else: ?> boolen-red <?php endif; ?>"></span></div>
</label>