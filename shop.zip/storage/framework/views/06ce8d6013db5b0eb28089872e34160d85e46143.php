<label>
    <?php echo e($field->label); ?>

    <select class="uk-select">
        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($data->{$field->foreign_key}==$item->{$field->foreign_key}): ?> selected <?php endif; ?> value="<?php echo e($item->{$field->foreign_key}); ?>"><?php echo e($item->{$field->name}); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</label>