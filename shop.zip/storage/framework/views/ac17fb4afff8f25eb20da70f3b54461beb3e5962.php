<li <?php if(empty(!$item->data)): ?> class="uk-parent" <?php endif; ?>>
    <a href="<?php echo e($item->Link); ?>"><i class="uk-margin-small-left fa fa-shopping-cart"></i><?php echo e($item->Label); ?></a>
    <?php if(empty(!$item->data)): ?>
        <ul class="uk-nav-sub">
            <?php echo $item->data; ?>

        </ul>
    <?php endif; ?>
</li>