<?php $__env->startSection('title','داشبورد'); ?>
<?php $__env->startSection('content'); ?>

    <div class="tm-content uk-padding-remove-vertical uk-section-muted uk-height-viewport">
        <div class="tm-container uk-container uk-container-expand uk-padding-small">
            <?php echo $Fields; ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>