<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
</label>
<input id="<?php echo e($field->name); ?>" name="<?php echo e($field->name); ?>" value="<?php echo e($data->{$field->name} ?? null); ?>" type="hidden">
<trix-editor input="<?php echo e($field->name); ?>"></trix-editor>