<label>
    <span class="label"><?php echo e($field->label); ?></span>
    <div class="body">
        <?php if(empty($data)): ?>
            چیزی پیدا نشد
        <?php else: ?>
            <?php echo e($data->{$field->displayTitleField}); ?>

        <?php endif; ?>
    </div>
</label>