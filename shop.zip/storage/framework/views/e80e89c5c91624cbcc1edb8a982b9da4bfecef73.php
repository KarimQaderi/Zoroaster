<?php $__env->startSection('content'); ?>

    <div class="uk-card card">

        <form class="BuilderFields" action="<?php echo e(route('Zoroaster.resource.update',['resoure'=> $request->resoureClass,'resourceId'=> $resources->{$model->getKeyName()}])); ?>" method="POST">
            <h1 class="resourceName">ویرایش <?php echo e($resourceClass->labels); ?></h1>

            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>


            <?php echo $fields; ?>


        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Zoroaster::layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>