<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
    <div class="body"><?php echo e(Zoroaster::getOptionsSelect($field,$data->{$field->name},'label')); ?></div>
</label>