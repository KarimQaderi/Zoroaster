<div class="uk-grid">
    <?php echo $data; ?>

</div>
