<?php $__env->startSection('content'); ?>

    <div class="uk-card card">

        <div class="BuilderFields">

            <h1 class="resourceName">مشاهدی <?php echo e($resourceClass->label); ?></h1>



            <?php echo $fields; ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Zoroaster::layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>