<?php $__env->startSection('title','داشبورد'); ?>
<?php $__env->startSection('content'); ?>

    <div class="uk-card uk-padding tm-card-default">

        <form action="<?php echo e(isset($id)? route($route,$id) : route($route)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if($method=='PUT'): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <?php echo $fields; ?>


            <div>
                <button class="uk-button uk-button-primary">ذخیره</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>