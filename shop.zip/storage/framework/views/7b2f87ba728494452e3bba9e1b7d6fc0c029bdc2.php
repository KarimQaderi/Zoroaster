<?php if(empty(!$data)): ?>
    <div class="uk-grid row RowOneCol">
        <div class="uk-width-1-1">
            <?php echo $data; ?>

        </div>
    </div>
<?php endif; ?>
