<label><?php echo e($data->label); ?>

    <input class="uk-input" name="<?php echo e($data->name); ?>" type="text" value="<?php echo e($data->value); ?>">
</label>