<label><?php echo e($d->name); ?>

<input name="<?php echo e($d->attribute); ?>" type="text" value="<?php echo e($d->value); ?>">
</label>