<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
</label>
<input id="<?php echo e($data->name); ?>" name="<?php echo e($data->name); ?>" value="<?php echo e($data->value); ?>" type="hidden" name="content">
<trix-editor input="<?php echo e($data->name); ?>"></trix-editor>