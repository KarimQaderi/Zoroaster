<label>
    <span class="label"><?php echo e($field->label); ?></span>
    <select class="uk-select" name="<?php echo e($field->name); ?>">
        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($data!==null && $data->{$field->foreign_key}==$item->{$field->foreign_key}): ?> selected <?php endif; ?> value="<?php echo e($item->{$field->foreign_key}); ?>"><?php echo e($item->{$field->displayTitleField}); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</label>