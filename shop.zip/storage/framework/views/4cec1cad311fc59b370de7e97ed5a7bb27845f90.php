<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
    <span class="uk-text-warning uk-text-small-2"><?php echo e(Zoroaster::getMeta($field,'helpText')); ?></span>
    <select class="uk-select" name="<?php echo e($field->name); ?>">
        <?php $__currentLoopData = Zoroaster::getMeta($field,'options'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($data->value==$item['value']): ?> selected <?php endif; ?> value="<?php echo e($item['value']); ?>"><?php echo e($item['label']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</label>