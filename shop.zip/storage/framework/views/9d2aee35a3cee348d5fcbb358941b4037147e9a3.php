<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
    <span class="uk-text-warning uk-text-small-2"><?php echo e(BuilderFields::getMeta($field,'helpText')); ?></span>
    <textarea rows="<?php echo e(BuilderFields::getMeta($field,'rows')); ?>" name="<?php echo e($data->name); ?>" class="uk-textarea"><?php echo e($data->value); ?></textarea>
</label>