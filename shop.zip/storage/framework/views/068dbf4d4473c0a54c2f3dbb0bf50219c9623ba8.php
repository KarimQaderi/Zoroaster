<?php $__env->startSection('content'); ?>

    <div class="uk-card card">

        <form class="BuilderFields"
              <?php if(isset($resources)): ?>
              action="<?php echo e(route('Zoroaster.resource.update',['resoure'=> $request->resoureClass,'resourceId'=> $resources->{$model->getKeyName()}])); ?>"
              <?php else: ?>
              action="<?php echo e(route('Zoroaster.resource.store',['resoure'=> $request->resoureClass ])); ?>"
              <?php endif; ?>
              method="POST">

            <h1 class="resourceName">
                <?php if(isset($resources)): ?>
                    ویرایش
                <?php else: ?>
                    اضافه کردن
                <?php endif; ?>
                <?php echo e($resourceClass->label); ?></h1>

            <?php echo csrf_field(); ?>

            <?php if(isset($resources)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>


            <?php echo $fields; ?>


        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Zoroaster::layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>