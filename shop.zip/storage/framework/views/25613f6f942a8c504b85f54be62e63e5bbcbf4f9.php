<?php $__env->startSection('title','داشبورد'); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-card uk-padding tm-card-default">
        <div class="uk-overflow-auto">
            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper uk-form dt-uikit no-footer">
                <div id="DataTables_Table_0_filter" class="dataTables_filter"><label>جست&zwnj;وجو:&ensp;<input type="search" class="uk-input" placeholder="" aria-controls="DataTables_Table_0"></label>
                </div>
                <div class="dataTables_length" id="DataTables_Table_0_length"><label>نمایش &nbsp; <select name="DataTables_Table_0_length" aria-controls="DataTables_Table_0" class="uk-select">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select> &nbsp; سطر در هر برگه</label></div>

                <table class="uk-table uk-table-small uk-table-striped uk-table-middle uk-table-divider data-table dataTable no-footer" id="DataTables_Table_0" role="grid"
                       aria-describedby="DataTables_Table_0_info">
                    <thead>
                    <tr role="row">
                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th data-column="row" class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="ascending"
                                aria-label="#مرتب سازی از بزرگ به کوچک"
                                style="width: 59px;"><?php echo e($field->label); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th data-column="oper" class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="عملیاتمرتب سازی از کوچک به بزرگ"
                            style="width: 134px;">
                            عملیات
                        </th>
                    </tr>
                    </thead>
                    <tbody>


                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td data-column="<?php echo e($field->name); ?>"><?php echo $__env->make('Fields.index.'.$field->component,['data'=>$value,'field'=>$field] , \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <?php echo $__env->make('back.BuilderField.inc.ActionButtonRow',['key'=>$primaryKey,'ActionButtonRow'=>$ActionButtonRow,'field'=>$field,'value'=>$value], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

                <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                    <?php echo $data; ?>

                </div>
                <div class="dataTables_info" id="DataTables_Table_0_info" role="status" aria-live="polite">نمایش <?php echo e($data->firstItem()); ?> تا <?php echo e($data->lastItem()); ?> از <?php echo e($data->total()); ?>

                    رکورد
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>