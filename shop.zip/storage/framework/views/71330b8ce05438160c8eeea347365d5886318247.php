<?php $__env->startSection('title','داشبورد'); ?>
<?php $__env->startSection('content'); ?>

    <div class="uk-card card">

        <form class="BuilderFields" action="<?php echo e(isset($id)? route($route,$id) : route($route)); ?>" method="POST">
            <h1 class="resourceName">
                <?php if($method=='PUT'): ?>
                    ویرایش
                    <?php else: ?>
                    اضافه کردن
                <?php endif; ?>
                <?php echo e($model->label()); ?>

            </h1>

            <?php echo csrf_field(); ?>
            <?php if($method=='PUT'): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>


            <?php echo $fields; ?>


        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('BuilderFields::back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>