<label><?php echo e($data->label); ?>

    <textarea rows="<?php echo e(BuilderField::getMeta($field,'rows')); ?>" name="<?php echo e($data->name); ?>" class="uk-textarea"><?php echo e($data->value); ?></textarea>
</label>