
<?php dd($field->viewIndex($data,$field)); ?>
<label><?php echo e($data->{$field->name}); ?></label>