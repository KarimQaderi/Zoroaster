<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
    <span class="uk-text-warning uk-text-small-2"><?php echo e(Zoroaster::getMeta($field,'helpText')); ?></span>
    <input class="uk-input" name="<?php echo e($field->name); ?>" type="text" value="<?php echo e($data->{$field->name} ?? null); ?>">
</label>