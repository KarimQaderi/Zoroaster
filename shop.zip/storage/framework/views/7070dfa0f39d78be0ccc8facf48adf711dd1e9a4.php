<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
    <div class="body"><?php echo $data->{$field->name}; ?></div>
</label>