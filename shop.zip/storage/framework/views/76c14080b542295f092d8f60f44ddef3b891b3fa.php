<div class="col <?php echo e($field->class); ?>">
    <?php echo $data; ?>

</div>