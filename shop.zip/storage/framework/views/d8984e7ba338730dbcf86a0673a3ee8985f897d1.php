<div class="uk-grid row">
    <?php echo $data; ?>

</div>
