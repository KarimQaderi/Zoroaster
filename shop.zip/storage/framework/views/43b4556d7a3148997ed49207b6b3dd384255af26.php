<?php if(empty(!$data)): ?>
    <div class="uk-grid row">
        <?php echo $data; ?>

    </div>
<?php endif; ?>