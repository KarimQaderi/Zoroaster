<div class="tm-user uk-text-center uk-light SidebarHeader">
    <h1 class="tm-date-gregorian">Zoroaster</h1>
    <span class="tm-date-gregorian"><?php echo e(now()); ?></span>
    <span><?php echo e(auth()->user()->name); ?></span>
</div>