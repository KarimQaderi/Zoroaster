<div class="<?php echo e($field->class); ?>">
    <h3><?php echo e($field->name); ?></h3>
    <?php echo $data; ?>

</div>