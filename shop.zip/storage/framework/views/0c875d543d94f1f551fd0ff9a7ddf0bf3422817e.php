<div class="panel <?php echo e($field->class); ?>">
    <?php if(empty(!$field->name)): ?>
        <h3><?php echo e($field->name); ?></h3>
    <?php endif; ?>
    <?php echo $data; ?>

</div>