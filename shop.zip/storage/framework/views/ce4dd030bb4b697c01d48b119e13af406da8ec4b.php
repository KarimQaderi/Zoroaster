<li class="<?php if(empty(!$item->data)): ?> uk-parent <?php endif; ?> <?php if(str_is("*".URL::current(),$item->Link) === true ): ?> uk-active <?php endif; ?> <?php if(str_contains($item->data,URL::current().'"')===true): ?> uk-open <?php endif; ?>">
    <a href="<?php echo e($item->Link); ?>"><i class="uk-margin-small-left" <?php if(empty(!$item->icon)): ?> uk-icon="<?php echo e($item->icon); ?>" <?php endif; ?> ></i><?php echo e($item->Label); ?></a>
    <?php if(empty(!$item->data)): ?>
        <ul class="uk-nav-sub">
            <?php echo $item->data; ?>

        </ul>
    <?php endif; ?>
</li>