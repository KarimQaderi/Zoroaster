<?php echo e(BuilderField::getOptionsSelect($field,$data->{$field->name},'label')); ?>

