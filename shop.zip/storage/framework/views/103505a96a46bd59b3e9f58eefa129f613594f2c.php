<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
    <span class="uk-text-warning uk-text-small-2"><?php echo e(BuilderFields::getMeta($field,'helpText')); ?></span>
    <input <?php if($data->value==true): ?> checked <?php endif; ?> name="<?php echo e($data->name); ?>" class="uk-checkbox" type="checkbox">
</label>