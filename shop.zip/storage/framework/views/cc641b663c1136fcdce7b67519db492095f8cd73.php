<label>
    <span class="label"><?php echo e($field->label); ?></span>&nbsp;
    <span class="uk-text-warning uk-text-small-2"><?php echo e(Zoroaster::getMeta($field,'helpText')); ?></span>
    <input <?php if(($data->{$field->name} ?? null )==true): ?> checked <?php endif; ?> name="<?php echo e($field->name); ?>" class="uk-checkbox" type="checkbox">
</label>