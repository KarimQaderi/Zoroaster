<ul id="side-menu" class="uk-nav-default uk-nav-parent-icon" uk-nav>
    {!! $item->data !!}
</ul>