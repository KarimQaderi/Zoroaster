@empty(!$data)
    <div class="uk-grid row">
        {!! $data !!}
    </div>
@endempty