{{ Zoroaster::getOptionsSelect($field,$data->{$field->name},'label') }}
