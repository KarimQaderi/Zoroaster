<div class="col {{ $field->class }}">
    {!! $data !!}
</div>