@empty(!$data)
    <div class="uk-grid row RowOneCol">
        <div class="uk-width-1-1">
            {!! $data !!}
        </div>
    </div>
@endempty
