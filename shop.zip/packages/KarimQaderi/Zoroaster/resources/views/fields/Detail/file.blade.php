<label>
    <span class="label">{{ $field->label }}</span>&nbsp;

</label>