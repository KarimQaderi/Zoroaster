<label>
    <span class="label">{{ $field->label }}</span>&nbsp;
    <div class="body">{{ $data->{$field->name} }}</div>
</label>