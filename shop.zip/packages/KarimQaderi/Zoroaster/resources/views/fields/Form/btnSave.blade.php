<label>
    <button class="btn uk-button uk-button-primary uk-border-rounded">ذخیره</button>
</label>