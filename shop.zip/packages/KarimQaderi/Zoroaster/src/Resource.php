<?php

    namespace KarimQaderi\Zoroaster;


    class Resource
    {

    }