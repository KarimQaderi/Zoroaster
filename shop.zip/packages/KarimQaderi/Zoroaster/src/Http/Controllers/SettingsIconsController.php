<?php

    namespace KarimQaderi\Zoroaster\Http\Controllers;

    use App\Http\Controllers\Controller;

    class SettingsIconsController extends Controller
    {
        public function handle()
        {

            return view('Zoroaster::Settings.icons');
        }


    }