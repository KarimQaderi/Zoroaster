<?php


    namespace KarimQaderi\BuilderFields;


    class BuilderFields
    {
        public static function routes()
        {
            return require __DIR__.'/routes.php';
        }



    }