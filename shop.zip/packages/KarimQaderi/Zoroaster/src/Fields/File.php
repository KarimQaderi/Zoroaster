<?php

    namespace KarimQaderi\Zoroaster\Fields;





    use KarimQaderi\Zoroaster\Fields\Other\Field;

    class File extends Field
    {

        /**
         * The field's component.
         *
         * @var string
         */
        public $component = 'file';



    }